package com.quickshulker.mixin;

import com.quickshulker.client.ShulkerHoverRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {

    @Shadow @Nullable protected Slot hoveredSlot;
    @Shadow protected int leftPos;
    @Shadow protected int topPos;

    @Invoker("getHoveredSlot")
    public abstract Slot invokeGetHoveredSlot(double mouseX, double mouseY);

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void onExtractRenderState(GuiGraphicsExtractor context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        AbstractContainerScreen<?> screen = (AbstractContainerScreen<?>) (Object) this;
        ShulkerHoverRenderer.render(context, screen, hoveredSlot, mouseX, mouseY, this.leftPos, this.topPos);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void onMouseClicked(MouseButtonEvent event, boolean guiIn, CallbackInfoReturnable<Boolean> cir) {
        Slot slot = invokeGetHoveredSlot(event.x(), event.y());
        if (slot == null || !slot.hasItem()) return;
        if (!slot.getItem().is(holder -> holder.is(net.minecraft.tags.ItemTags.SHULKER_BOXES))) return;

        Player player = Minecraft.getInstance().player;
        if (player == null) return;
        if (slot.container != player.getInventory()) return;

        int selected = ShulkerHoverRenderer.getSelectedSlot(slot.index);

        if (event.button() == 1) {
            ShulkerHoverRenderer.sendExtract(slot.index, selected);
            cir.setReturnValue(true);
        } else if (event.button() == 0) {
            ItemStack cursor = player.containerMenu.getCarried();
            if (!cursor.isEmpty()) {
                ShulkerHoverRenderer.sendInsert(slot.index);
                cir.setReturnValue(true);
            }
        }
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true)
    private void onMouseScrolled(double mouseX, double mouseY, double horizontal, double vertical, CallbackInfoReturnable<Boolean> cir) {
        if (ShulkerHoverRenderer.handleScroll(hoveredSlot, vertical)) {
            cir.setReturnValue(true);
        }
    }
}
